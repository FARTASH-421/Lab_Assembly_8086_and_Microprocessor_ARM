#include "stm32f4xx.h"
#include "stdio.h"
static unsigned int digit[10]= {0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7c,0x07,0x7f,0x6f};
static  int numbers[20]={2, 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
static unsigned int a = 0;
static	 int b = 2;
	
void delayMs(int n);
void nextnumber(void);
void prevnumber(void);
	
int main(void) {
	
		RCC->AHB1ENR |= 2; 															/* enable GPIOB clock */ 
		RCC->AHB1ENR |= 4; 															/*enable GPIOC clock */
		GPIOC->MODER &= ~0x0000FFFF; 										/* clear pin mode */
		GPIOC->MODER |= 0x00005555; 										/* set pins to output mode */ 
		GPIOB->MODER &= ~0x0000000F; 										/* clear pin mode */ 
		GPIOB->MODER |= 0x00000000; 										/* set pins to output mode */

	
		int changeup = 0, changedn = 0;
		int i = 0;
		int temp = 0,temp1 = 0 , ten = 10 ;
			
		for(;;) {
			
			ten = 10;
			while (1) {
					temp = b / ten ;
					if (temp == 0 ){
						break;
					}	
					ten *=  10;
			}
			temp = b;
			temp1 = b;
			ten /= 10;
			
			while (1){
					temp = temp1 / ten ;
					switch(temp){
						case 0 :  a = 0;  break;
						case 1 :  a = 1;  break;
						case 2 : 	a = 2;  break;
						case 3 : 	a = 3;  break;
						case 4 : 	a = 4;  break;
						case 5 : 	a = 5;  break;
						case 6 : 	a = 6;  break;
						case 7 : 	a = 7;  break;
						case 8 :  a = 8;  break;
						case 9 :  a = 9;  break;
					
					}
					
					GPIOC->ODR = digit[a]; 								/* display tens digit */ 
					delayMs(15);
					if  ( (GPIOB->IDR & 1 )==  0  ){
							
						changeup = 1;
							
					}else if ( (GPIOB->IDR & 2 ) ==  0 ){
							changedn = 1;
					}

					temp1 = temp1 % ten;
					ten /= 10;
					
					if ( ten == 0 ) {
						break;
						}		
				}
				
				if  ( (GPIOB->IDR & 1 )==  0 ||  changeup == 1  ){		
					nextnumber();
					changeup = 0 ;
				} else if ((GPIOB->IDR & 2 )==  0 ||  changedn == 1 ){
					
					prevnumber();
					changedn = 0 ;
					
				}

					GPIOC->ODR = 0x88; 								/* display tens digit */ 
					GPIOB->BSRR = 0x00010000; 				/* deselect ones digit */ 
					delayMs(15);
		} 

}

/*---------------- 16 MHz SYSCLK -----------------------------------*/
void delayMs(int n) {
	int i;
	for (; n > 0; n--)
		for (i = 0; i < 31950; i++);

}


void nextnumber (){

		int temp = b + 1, remain = 0 , quof = 2, bound = 0  ;
		int holder = 0;
    int numHolder = temp;
		
	while (1){
				
	
			holder = 0;
			numHolder = temp;
			while(1){
				holder = 0;
				temp = numHolder;
				
				while(temp>0){
						holder = holder*10;
						holder = holder+(temp%10);
						temp =temp/10;
				}
				
				if (numHolder == holder){
						break;
				} else {
						numHolder = numHolder + 1; 
				}
		}
		 	
		temp = numHolder ;
		bound = temp /2 ;
		quof = 2;
		
		while (quof <= bound){			
			remain = temp % quof ;
				if (remain == 0 ){
					 break;
				}
				
				quof = quof + 1;
			}

			if ( quof > bound )  {
				b = temp ;
				break;
			}		
			
		//break;
		temp = temp +1;
	}
	
}


void prevnumber (){

		int temp = b - 1, remain = 0 , quof = 2, bound = 0  ;
		int holder = 0;
    int numHolder = temp;
		
		while (1){
						
			
				holder = 0;
				numHolder = temp;
				while(1){
						holder = 0;
						temp = numHolder;
						while(temp>0){
								holder = holder*10;
								holder = holder+(temp%10);
								temp =temp/10;
						}
						
						if (numHolder == holder)
							break;
						else {
						numHolder = numHolder - 1; 
						}
				}
			
				temp = numHolder ;
				bound = temp /2 ;
				quof = 2;
				while (quof <= bound){
				
				remain = temp % quof ;
					if (remain == 0 ){
						break;
					}
					
					quof = quof + 1;
				
				}
					
				if ( quof > bound )  {
					
					b = temp ;
					
					break;
				}		
			
				//break;
				temp = temp -1;
			}
	
}