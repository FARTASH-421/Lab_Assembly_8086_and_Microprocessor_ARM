#include "stm32f4xx.h"

void delayMs(int n);
void LCD_command(unsigned char command);
void LCD_command_noPoll(unsigned char command);
void LCD_data(char data);
void LCD_init(void);
void LCD_ready(void);
void PORTS_init(void);
void configureInterrupts(void) ;
void EXTI3_IRQHandler(void);
void TIM2_IRQHandler(void);
void ShowPasOnLCD(int n);
void showEQV_Number(int v);
volatile int n;
volatile int speed;

#define RS 0x20 /* PB5 mask for reg select */
#define RW 0x40 /* PB6 mask for read/write */
#define EN 0x80 /* PB7 mask for enable */


int main(void) {
/* initialize LCD controller */
	LCD_init();
	configureInterrupts();
	n = 1;
	speed = 1;
	while(1) {
		
		showEQV_Number(n);
		delayMs(500);
		/* clear LCD display */
		LCD_command(1);
		delayMs(500);
	}
}
/* Initialize port pins then initialize LCD
controller */
void LCD_init(void) {
	PORTS_init();
	delayMs(30); /* initialization sequence */
	LCD_command_noPoll(0x30);
	/* LCD does not respond to status poll yet */
	delayMs(10);
	LCD_command_noPoll(0x30);
	delayMs(1);
	LCD_command_noPoll(0x30); /* busy flag cannot be
	polled before this */
	LCD_command(0x38); /* set 8-bit data, 2-line, 5x7
	font */
	LCD_command(0x06); /* move cursor right after each
	char */
	LCD_command(0x01); /* clear screen, move cursor to
	home */
	LCD_command(0x0F); /* turn on display, cursor
	blinking */
}
void PORTS_init(void) {
	
	 /* Configure the LED pin (PB13) as output
	   PB5 for LCD R/S */
		/* PB6 for LCD R/W */
		/* PB7 for LCD EN */
		RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN|RCC_AHB1ENR_GPIOBEN|RCC_AHB1ENR_GPIOCEN;
    GPIOB->MODER |= GPIO_MODER_MODER7_0|GPIO_MODER_MODER6_0|GPIO_MODER_MODER12_0;
		GPIOB->MODER |= GPIO_MODER_MODER5_0;
    
		// Configure the pushbutton pin (PA3) as input
    GPIOA->MODER &= ~GPIO_MODER_MODER3;
		GPIOA->MODER |= GPIO_MODER_MODER3_1;
    GPIOA->PUPDR &= ~GPIO_PUPDR_PUPDR3;
		GPIOA->PUPDR |= GPIO_PUPDR_PUPDR3_1;
		GPIOB->BSRR = 0x00C00000; /* turn off EN and R/W */
	
		/* This function waits until LCD controller is
		ready to
		PC0-PC7 for LCD D0-D7, respectively. */
		GPIOC->MODER &= ~0x0000FFFF; /* clear pin mode */
		GPIOC->MODER |= 0x00005555; /* set pin output mode
*/
}


void LCD_ready(void) {
		char status;
		/* change to read configuration to poll the status
		register */
		GPIOC->MODER &= ~0x0000FFFF; /* clear pin mode */
		GPIOB->BSRR = RS << 16; /* RS = 0 for status register */
		GPIOB->BSRR = RW; /* R/W = 1 for read */
		
		do { /* stay in the loop until it is not busy */
				GPIOB->BSRR = EN; /* pulse E high */
				delayMs(0);
				status = GPIOC->IDR; /* read status register */
				GPIOB->BSRR = EN << 16; /* clear E */
				delayMs(0);
		} while (status & 0x80); /* check busy bit */
		
		/* return to default write configuration */
		GPIOB->BSRR = RW << 16; /* R/W = 0, LCD input */
		GPIOC->MODER |= 0x00005555; /* Port C as output */
}

void LCD_command(unsigned char command) {
		LCD_ready(); /* wait for LCD controller ready */
		GPIOB->BSRR = (RS | RW) << 16; /* RS = 0, R/W = 0
		*/
		GPIOC->ODR = command; /* put command on data bus */
		GPIOB->BSRR = EN; /* pulse E high */
		delayMs(0);
		GPIOB->BSRR = EN << 16; /* clear E */
}

void LCD_command_noPoll(unsigned char command) {
	GPIOB->BSRR = (RS | RW) << 16; /* RS = 0, R/W = 0
	*/
	GPIOC->ODR = command;
	/* put command on data bus */
	GPIOB->BSRR = EN; /* pulse E high */
	delayMs(0);
	GPIOB->BSRR = EN << 16; /* clear E */
}
void LCD_data(char data) {
	LCD_ready(); 								/* wait for LCD controller ready */
	GPIOB->BSRR = RS;						 /* RS = 1 */
	GPIOB->BSRR = RW << 16; /* R/W = 0 */
	GPIOC->ODR = data; /* put data on data bus */
	GPIOB->BSRR = EN; /* pulse E high */
	delayMs(0);
	GPIOB->BSRR = EN << 16;
	/* clear E */
}
/* delay n milliseconds (16 MHz CPU clock) */
void EXTI3_IRQHandler(void) {
    if (EXTI->PR & EXTI_PR_PR3) {
       /* // Interrupt occurred on pin 3 of GPIOA (external pushbutton)*/

        if(speed==1){
					speed = 2;
					TIM2->PSC = (32000/speed) - 1; /* divided by 16000 */
				}else speed = 1;
        /* Clear the interrupt pending bit*/
        EXTI->PR = EXTI_PR_PR3;
    }
}


void delayMs(int n) {
	int i;
	for (; n > 0; n--)
		for (i = 0; i < 3195; i++) ;
}

void configureInterrupts(void) {
	
	
		__disable_irq();
    // Enable the clock for GPIOA and GPIOB
    
		RCC->APB2ENR |= 0x4000;

			/* setup TIM2 */
		RCC->APB1ENR |= 1; /* enable TIM2 clock */
		TIM2->PSC = (32000/speed) - 1; /* divided by 16000 */
		TIM2->ARR = 1000 - 1; /* divided by 1000 */
		TIM2->CR1 = 1; /* enable counter */
		TIM2->DIER |= 1; /* enable UIE */

    // Connect the EXTI line to the pushbutton pin
    SYSCFG->EXTICR[0] &= ~SYSCFG_EXTICR1_EXTI3;
    SYSCFG->EXTICR[0] |= SYSCFG_EXTICR1_EXTI3_PA;

    // Configure the EXTI line to trigger on rising and falling edges
    EXTI->IMR |= EXTI_IMR_MR3;
    EXTI->RTSR |= EXTI_RTSR_TR3;
    //EXTI->FTSR |= EXTI_FTSR_TR3;
    // Enable the interrupt in the NVIC
    NVIC_SetPriority(EXTI3_IRQn, 0);
    NVIC_EnableIRQ(EXTI3_IRQn);
		NVIC_EnableIRQ(TIM2_IRQn); /* enable interrupt in
		NVIC */
		__enable_irq();
}

void TIM2_IRQHandler(void) {
	TIM2->SR = 0; /* clear UIF */
	n++;
	/* toggle LED */
}
void showEQV_Number(int n){
		
		char* arr = "WELL COME TO SBU";
		for (int i = 0; i <= 16; i++){
				 LCD_data(*(arr+i));
		}
}
