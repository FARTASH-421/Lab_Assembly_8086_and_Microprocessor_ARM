#include "stm32f4xx_hal.h"
#include "stm32f4xx_hal_tim.h"
#include "stm32f4xx.h"
#include "LCD16x2Lib/LCD.h"


volatile uint32_t dutyCycle = 50;
void Delay(uint32_t delay);

volatile uint32_t msTicks = 0;
volatile uint32_t blinkPeriod = 500;
volatile uint32_t buttonDebounceDelay = 200;
volatile uint16_t check = 0;
volatile uint16_t readKey;
	
//void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim);

void ADC_Config(void);


uint32_t Read_ADC();
void SystemClock_Config(void);
void PrintTime(void);
void PrintTimeLED(void);
void TIM2_Config(void);
void TIM3_Config(void) ;
void runWich(void);
void led_onOff(void);
void lcd_lowHigh(void);
int evaluateButton(int x);
void ClearLCD(void);
void PrintTimeLCD(void);


int main(void)
{
	SystemCoreClockUpdate();
	HAL_Init();
	
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();
	__HAL_RCC_GPIOC_CLK_ENABLE();
	
	
	
	
	GPIO_InitTypeDef PinConfig;
	PinConfig.Pin = GPIO_PIN_5;
	PinConfig.Mode = GPIO_MODE_OUTPUT_PP;
	PinConfig.Pull = GPIO_NOPULL;
	PinConfig.Speed = GPIO_SPEED_FREQ_HIGH;
	HAL_GPIO_Init(GPIOA, &PinConfig);
	
	TIM2_Config();
	TIM3_Config();
	LCD_Init();

	 //SystemClock_Config();
    
    // Enable GPIOA clock
    //RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
		RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN | RCC_AHB1ENR_GPIOCEN;


    
    // Configure PA1 as analog mode
    GPIOA->MODER |= GPIO_MODER_MODER0;
    
    // Configure ADC1
    ADC_Config();
    
    uint32_t adcValue ;


	while(1){

		PrintTime();
		adcValue = Read_ADC();
	
		if (adcValue == 63)
			runWich();
	
	}
	
	return 0;
}


void runWich(void){	
	
	if(check%2 == 0){
		check++;
		led_onOff();
		
	}
	else{
		check++;
		lcd_lowHigh();
		
	}
}

void ClearLCD(void){
	for (int x = 0; x < 16; x++) {     // Erases current cursor
			char str[] = " ";
			LCD_Puts(x,1, str);
		}
}


void led_onOff(void){
		
		ClearLCD();
		
		int activeButton = 0;
		while (activeButton == 0) {
				int button;
				readKey = Read_ADC();
				if (readKey < 790) {
					Delay(10);
					readKey = Read_ADC();
				}
				
				button = evaluateButton(readKey);
				switch (button) {
							case 0: 																			// When button returns as 0 there is no action taken
								break;
							case 1:
									activeButton++;
								break;
							case 2:		// UP key press
								blinkPeriod += 100;
								TIM3->ARR = blinkPeriod;
								PrintTimeLCD();
								break;
							case 3:		// Down key press
								if (blinkPeriod > 10) blinkPeriod -= 100;
								TIM3->ARR = blinkPeriod;
								PrintTimeLCD();
								break;
					}
				
				PrintTime();
		}
		ClearLCD();
	
}

void lcd_lowHigh(void){
	
	ClearLCD();
	
	int activeButton = 0;
  while (activeButton == 0) {
    int button;
    readKey = Read_ADC();
    if (readKey < 790) {
      Delay(10);
      readKey = Read_ADC();
    }
		
    button = evaluateButton(readKey);
    switch (button) {
					case 0: 																			// When button returns as 0 there is no action taken
						activeButton = 1;
						break;
					case 1:																				// press button Right for high light LCD
							if (dutyCycle <= 90) dutyCycle += 10;
							TIM3->CCR1 = (dutyCycle * (TIM3->ARR + 1)) / 100;
							PrintTimeLED();
						break;
					case 2:
							activeButton++;
						break;
					case 3:
						break;
					case 4:																						// press button Left for low light LCD
						 if (dutyCycle >= 10) dutyCycle -= 10;
							TIM3->CCR1 = (dutyCycle * (TIM3->ARR + 1)) / 100;
							PrintTimeLED();
						break;
					
			}
		
			PrintTime();
		}
	ClearLCD();
}

int evaluateButton(int x) {
  int result = 0;
  if (x < 7) {
    result = 1; 						// right
  } else if (x < 13) {
    result = 2; 						// up
  } else if (x < 29) {
    result = 3; 						// down
  } else if (x < 46) {
    result = 4; 						// left
  }else{
		result = 0;
	}
  return result;
}

void PrintTime(void){
	
	char str[20];
	snprintf(str, sizeof(str), "Time: %lu ms", msTicks);
	LCD_Puts(0,0, str);
		
}

void PrintTimeLED(void){

	char str[20];
	snprintf(str, sizeof(str), "LCD: %lu ms",dutyCycle );
	LCD_Puts(0,1, str);
		
}

void PrintTimeLCD(void){

	char str[20];
	snprintf(str, sizeof(str), "LED: %lu ms",blinkPeriod );
	LCD_Puts(0,1, str);
		
}
void SysTick_Handler(void)
{
  HAL_IncTick();
}



void TIM2_Config(void) {
    // Enable TIM2 clock
    RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;

    // Configure TIM2: Prescaler and Period for 1 ms ticks
    TIM2->PSC = 83 - 1; // Prescaler to count in 0.1 ms steps
    TIM2->ARR = 190 - 1;   // Auto-reload for 1 ms interrupts

    // Enable TIM2 interrupt
    TIM2->DIER |= TIM_DIER_UIE;
    NVIC_EnableIRQ(TIM2_IRQn);

    // Enable TIM2
    TIM2->CR1 |= TIM_CR1_CEN;
}


void TIM2_IRQHandler(void) {
    if (TIM2->SR & TIM_SR_UIF) {
        TIM2->SR &= ~TIM_SR_UIF; // Clear update interrupt flag
        msTicks++;
    }
}

void TIM3_Config(void) {
    // Enable TIM3 clock
    RCC->APB1ENR |= RCC_APB1ENR_TIM3EN;

    // Configure TIM3 for Output Compare
    TIM3->PSC = 160 - 1; // Prescaler for 1 ms ticks
    TIM3->ARR = blinkPeriod; // Auto-reload value for blink period
    TIM3->CCR1 = blinkPeriod / 2; // Compare value for 50% duty cycle

    // Configure TIM3 Channel 1 for Output Compare toggle mode
    TIM3->CCMR1 |= TIM_CCMR1_OC1M_0 | TIM_CCMR1_OC1M_1;
    TIM3->CCER |= TIM_CCER_CC1E;

    // Enable TIM3 interrupt
    TIM3->DIER |= TIM_DIER_UIE;
    NVIC_EnableIRQ(TIM3_IRQn);

    // Enable TIM3
    TIM3->CR1 |= TIM_CR1_CEN;
}


void TIM3_IRQHandler(void) {
    if (TIM3->SR & TIM_SR_UIF) {
        TIM3->SR &= ~TIM_SR_UIF; // Clear update interrupt flag
        // Toggle LED
        	GPIOA->ODR ^= (1<<5);
    }
}



void Delay(uint32_t delay) {
    for (volatile uint32_t i = 0; i < delay * 10; i++);
}

void ADC_Config(void) {
	

	   // Enable ADC1 clock
    RCC->APB2ENR |= RCC_APB2ENR_ADC1EN;
    
    // Configure ADC1
    ADC1->CR1 = 0;  // Reset control register 1
    ADC1->CR2 = 0;  // Reset control register 2
    ADC1->SQR3 = 0; // Reset sequence register 3
    
    // Set ADC resolution to 12 bits
    ADC1->CR1 |= ADC_CR1_RES_0 | ADC_CR1_RES_1;
    
    // Set ADC clock mode to synchronous, with PCLK2 as the clock source
    ADC1->CR2 |= ADC_CR2_ADON; // Enable ADC
    ADC1->CR2 |= ADC_CR2_CONT; // Enable continuous conversion mode
    ADC1->CR2 |= ADC_CR2_EXTSEL; // Set external trigger to start conversion
    ADC1->CR2 |= ADC_CR2_EXTEN_0; // Enable external trigger rising edge
    
    // Configure regular channel sequence length (1 conversion)
    ADC1->SQR1 |= 0 << ADC_SQR1_L_Pos;
		
	
	
	
}


uint32_t Read_ADC() {
	
		ADC1->CR2 |= (1<<30);
		while( (ADC1->SR & (1<<1)) == 0);
	
		unsigned int ADC_Result = ADC1->DR & 0X0FFF;
    return ADC_Result;
	
}



void SystemClock_Config(void) {
    // Configure the system clock using the PLL
    RCC->CR |= RCC_CR_HSEON; // Enable HSE (High Speed External) clock
    while (!(RCC->CR & RCC_CR_HSERDY)); // Wait until HSE is ready
    
    // PLL configuration
    RCC->PLLCFGR = (8 << RCC_PLLCFGR_PLLM_Pos) |   // PLLM = 8
                   (336 << RCC_PLLCFGR_PLLN_Pos) |  // PLLN = 336
                   (4 << RCC_PLLCFGR_PLLP_Pos) |   // PLLP = 4 (DIV2)
                   (7 << RCC_PLLCFGR_PLLQ_Pos) |   // PLLQ = 7
                   RCC_PLLCFGR_PLLSRC_HSE;         // PLL source = HSE
    
    // Enable the PLL
    RCC->CR |= RCC_CR_PLLON;
    while (!(RCC->CR & RCC_CR_PLLRDY)); // Wait until PLL is ready
    
    // Set the flash latency to 5 wait states (for 168 MHz)
    FLASH->ACR = FLASH_ACR_LATENCY_5WS;
    
    // Select the PLL as the system clock source
    RCC->CFGR |= RCC_CFGR_SW_PLL;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_PLL); // Wait until PLL becomes the system clock
}

void Error_Handler(void) {
    // Stay here in case of error
    while (1);
}