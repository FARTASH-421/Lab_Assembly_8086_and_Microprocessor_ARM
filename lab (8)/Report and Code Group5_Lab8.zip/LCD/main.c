#include "stm32f4xx_hal.h"
#include "stm32f4xx.h"
#include "LCD16x2Lib/LCD.h"
#include "string.h"



char* itoa(int value, char* result, int base);
void UpdateLCD(void);
uint32_t get_SYSCLK_frequency(void);
void configure_PC2_PC3_exti(void);
void EXTI2_IRQHandler(void);
void EXTI3_IRQHandler(void);

char* message = "Don't Marry. Save Money and Travel  ";
int iLinText = 1;
int iCusor = 0;
uint32_t counter = 1;


int main(void)
{
	// SystemCoreClockUpdate();
	HAL_Init();
	
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();
	__HAL_RCC_GPIOC_CLK_ENABLE();
	configure_PC2_PC3_exti();
	
	uint32_t sys_clk = get_SYSCLK_frequency();
	counter  = sys_clk;
	

	
	
	LCD_Init();

	LCD_Puts(9, 0, "Hz");
	char str_to_num[5];

	while (1){	
			
			itoa(counter, str_to_num, 10);
			LCD_Puts(0, 0, str_to_num);
			UpdateLCD();
			HAL_Delay(100);
	}
	
	return 0;
}

void SysTick_Handler(void)
{
  HAL_IncTick();
}


void UpdateLCD(){
	
  int iLen = strlen(message);
  if(iCusor == iLen -1){
    iCusor = 0;
  }
	
	LCD_CursorSet(0, 1);
  if(iCusor < iLen -16){
      for(int iChar = iCusor; iChar < iCusor+16; iChar++){
        LCD_Put(message[iChar]);
      }
  } else{
			for(int iChar = iCusor; iChar < (iLen - 1); iChar++){
				LCD_Put(message[iChar]);
		 }
			
		 for(int iChar1 = iCusor; iChar1 <= 16 -(iLen - iCusor); iChar1++){
        LCD_Put(message[iChar1]);
      }
  }

	iCusor++;
}

char* itoa(int value, char* result, int base) {
    // check that the base if valid
    if (base < 2 || base > 36) { *result = '\0'; return result; }

    char* ptr = result, *ptr1 = result, tmp_char;
    int tmp_value;

    do {
        tmp_value = value;
        value /= base;
        *ptr++ = "zyxwvutsrqponmlkjihgfedcba9876543210123456789abcdefghijklmnopqrstuvwxyz" [35 + (tmp_value - value * base)];
    } while ( value );

    // Apply negative sign
    if (tmp_value < 0) *ptr++ = '-';
    *ptr-- = '\0';
  
    // Reverse the string
    while(ptr1 < ptr) {
        tmp_char = *ptr;
        *ptr--= *ptr1;
        *ptr1++ = tmp_char;
    }
    return result;
}

//-----------------------------   configure_PC2_PC3_exti ------------------------------------------------------
void configure_PC2_PC3_exti(void) {
    //  Enable the GPIOC Clock
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOCEN;

    //  Configure PC2 and PC3 as Inputs
    GPIOC->MODER &= ~(3 << (2 * 2));  								// Clear mode bits for PC2 (00 is input)
    GPIOC->MODER &= ~(3 << (3 * 2));  								// Clear mode bits for PC3 (00 is input)

    //  Configure PC2 and PC3 as Pull-Up (optional, if needed)
    GPIOC->PUPDR &= ~(3 << (2 * 2));  								// Clear pull-up/pull-down bits for PC2
    GPIOC->PUPDR |= (1 << (2 * 2));   								// Set pull-up (01 is pull-up) for PC2
    GPIOC->PUPDR &= ~(3 << (3 * 2));  								// Clear pull-up/pull-down bits for PC3
    GPIOC->PUPDR |= (1 << (3 * 2));   								// Set pull-up (01 is pull-up) for PC3

    //  Configure SYSCFG for EXTI2 and EXTI3
    RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN;  						// Enable SYSCFG clock
    SYSCFG->EXTICR[0] &= ~(SYSCFG_EXTICR1_EXTI2);  		// Clear the EXTI2 bits
    SYSCFG->EXTICR[0] |= SYSCFG_EXTICR1_EXTI2_PC;  		// Set EXTI2 source to PC2

    SYSCFG->EXTICR[0] &= ~(SYSCFG_EXTICR1_EXTI3);  		// Clear the EXTI3 bits
    SYSCFG->EXTICR[0] |= SYSCFG_EXTICR1_EXTI3_PC;  		// Set EXTI3 source to PC3

    //  Enable EXTI2 and EXTI3 lines
    EXTI->IMR |= (1 << 2); 														 // Unmask EXTI2
    EXTI->IMR |= (1 << 3);  													// Unmask EXTI3

    EXTI->RTSR |= (1 << 2); 													// Trigger on rising edge for EXTI2 (for falling edge, use EXTI->FTSR)
    EXTI->RTSR |= (1 << 3); 													// Trigger on rising edge for EXTI3 (for falling edge, use EXTI->FTSR)

    //  Enable EXTI2 and EXTI3 Interrupts in NVIC
    NVIC_EnableIRQ(EXTI2_IRQn);
    NVIC_EnableIRQ(EXTI3_IRQn);
}

// -----------------------------  Interrupt handler for EXTI line 2 (PC2)-----------------------------------
void EXTI2_IRQHandler(void) {
    if (EXTI->PR & (1 << 2)) {
        if(counter > 0)
					counter -= 1;
        EXTI->PR = (1 << 2);
    }
}

// -------------------------------  Interrupt handler for EXTI line 3 (PC3) ---------------------------------
void EXTI3_IRQHandler(void) {
    if (EXTI->PR & (1 << 3)) {
				counter += 1;
        EXTI->PR = (1 << 3);
    }
}

// --------------------------------------------------------------------------------------------------------------
uint32_t get_SYSCLK_frequency(void) {
	
    uint32_t sysclk_freq;
    uint32_t pll_m, pll_n, pll_p, pll_q, pll_source;
    uint32_t hse_value = 8000000;  																								// Assume HSE is 8 MHz, adjust if different

    // Read SWS bits to determine the current SYSCLK source
    switch ((RCC->CFGR & RCC_CFGR_SWS) >> 2) {	
        case 0x00:  																															// HSI used as system clock
            sysclk_freq = 16000000;  																							// HSI frequency is 16 MHz
            break;
        case 0x01: 																																// HSE used as system clock
            sysclk_freq = hse_value;  																						// HSE frequency
            break;
        case 0x02:  																															// PLL used as system clock
            pll_source = (RCC->PLLCFGR & RCC_PLLCFGR_PLLSRC) >> 22;
            pll_m = RCC->PLLCFGR & RCC_PLLCFGR_PLLM;
            pll_n = (RCC->PLLCFGR & RCC_PLLCFGR_PLLN) >> 6;
            pll_p = (((RCC->PLLCFGR & RCC_PLLCFGR_PLLP) >> 16) + 1) * 2;

            if (pll_source == 0) {
                sysclk_freq = (16000000 / pll_m) * pll_n / pll_p;									// HSI is the PLL source
            } else {
                sysclk_freq = (hse_value / pll_m) * pll_n / pll_p;								// HSE is the PLL source
            }
            break;
        default:
            sysclk_freq = 0;  																										// Should not happen, indicate error
            break;
    }
    return sysclk_freq;
}